<?php
namespace AliyunMNS\Exception;

use AliyunMNS\Exception\MnsException;

class ReceiptHandleErrorException extends MnsException
{
}

?>
