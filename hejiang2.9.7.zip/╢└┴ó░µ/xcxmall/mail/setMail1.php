<p>尊敬的:<b><?php echo $store_name; ?></b></p>
<p style="color: #ff4544;">您有一条新的退款订单</p>
<p>请及时进入商城处理</p>